export const isUser = (user) => {
  return user == "You" ? true : false;
};
