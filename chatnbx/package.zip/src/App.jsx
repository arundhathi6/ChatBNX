
import './App.css';
import MenuBar from './components/Sidebar';

function App() {
  return (
    <>
      <MenuBar />
    </>
  );
}

export default App;
